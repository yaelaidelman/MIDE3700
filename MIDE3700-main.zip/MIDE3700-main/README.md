# MIDE3700
Proyecto de app de astronomia

Puedes cambiar el tamaño de resolución de pantalla en el archivo /Configuraciones/resolucion.txt
    altura,ancho (sin espacios)

git clone https://github.com/dome0luis0valentin/MIDE3700

cd MIDE3700

pip install -r requirement.py

Para ejecutar

python3 MIDE3700.py
